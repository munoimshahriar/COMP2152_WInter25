# Additional information
Yɛfa no sɛ woakenkan mfitiaseɛ nkyerɛkyerɛ no dedaw ansa na woaba ha.

### [Commit bi a Wɔsesa](amending-a-commit-twi.md)
Saa krataafa yi bɛma wo nsɛm a ɛhia sɛ wobɛsesa commit wɔ akyirikyiri akoraeɛ:> Fa yei siesie commit a woayɛ.


### [Git a Wɔrehyehyɛ](configuring-git.md)
Saa krataafa yi bɛma wo nsɛm a wuhia na wode asiesie ɔdefoɔ ho nsɛm ne akwan foforɔ a wobɛfa so wɔ git mu:> Fa yei di dwuma ma wo git nhyehyɛɛ no ​​so tumi yie.

### [Wo Fork a Wobɛma Ne Adekorabea no Ahyia a Ɛsono](forking-a-repository-twi.md)
Saa nwoma yi ma wo nsɛm a ɛfa sɛdeɛ wobɛma forked repository ayɛ foforɔ wɔ source repository no ho. 
Eyi ho hia, na yɛwɔ anidaso sɛ wo ne afoforo pii bɛboa ma wɔayɛ adwuma yi.

### [Commit a Wobɛtu akɔ Baa Dwumadibea a Ɛsono](committing-to-a-forked-repository-twi.md)

Saa krataafa yi bɛma wo nsɛm a wuhia na wode commit akɔ baa dwumadibea foforo: Di anammɔn yi akyi na wode commit akɔ baa dwumadibea foforo.

### [Fael bi a Wobeyi afi Mu] (adding-a-file-to-a-repository-twi.md)
Kratafa yi bɛma wo nsɛm a wuhia na wode ayi fael bi afi wo mpɔtam hɔ adekorabea: Di anammɔn yi akyi na sua sɛnea wobɛpopa fael bi ansa na woayɛ commit.

### [Baa Biara a Wobeyi Fi Wo Adekorabea no Ahyia a Ɛsono](adding-an-existing-file-to-a-repository-twi.md)

Saa krataafa yi bɛma wo nsɛm a wuhia na wode apopa baa dwumadibea bi afi wo adekorabea: Di anammɔn yi akyi bere a wɔaka wo twe abisade no abom akyi nkutoo.

### [Nkabom Ntawntawdi a Wobesiesie](creating-a-pull-request-twi.md)

Kratafa yi bɛma wo nsɛm a wuhia na wode asiesie nkabom ntawntawdi ho nsɛm: Di anammɔn yi akyi na woasiesie nkabom ntawntawdi a ɛtaa yɛ ɔhaw yi.

### [Wo Adekorabea a Wɔwɔ Git a Wɔrehyɛ](configuring-a-repository-for-git-twi.md)

Saa krataafa yi bɛma wo nsɛm a wuhia na wode asiesie wo adekorabea a wɔwɔ git a wɔrehyɛ: Di anammɔn yi akyi na wode asiesie wo adekorabea a wɔwɔ git a wɔrehyɛ.

### [San kɔ Commit bi so](reverting-a-commit-twi.md)

Saa krataafa yi bɛboa wo sɛ ɛhia sɛ wosan kɔ commit a atwam wɔ akyirikyiri akoraeɛ no so a. 

### [Squashing Commits a Wɔde Di Dwuma](squashing-commits-twi.md)

Saa krataafa yi bɛkyerɛ wo sɛnea wobɛbɔ commits pii akɔ commit biako mu:Fa eyi di dwuma sɛ wopɛ sɛ wode pull request kɔ na reviewer no ka kyerɛ wo sɛ "squash" commits nyinaa kɔ biako mu a nkrasɛm a ɛkɔ akyiri ka ho a.

### [Mpɔtam Hɔ Commit bi a Wɔretu](resetting-a-commit-twi.md)

Saa krataafa yi ma wo nsɛm a wuhia na wode asan ahyɛ commit bi a ɛwɔ wo mpɔtam hɔ akorae no mu.

### [Nkitahodi a Mfaso Wɔ So](useful-links-for-git-twi.md)

Saa krataafa yi yɛ nea wɔde ama afotuo ne akwansideɛ sites, blogs, ne sites a ɛboa mpɛn pii a ɛma yɛn asetena yɛ mmerɛ nyinaa.
Wɔyɛ nsɛm a wɔde gyina hɔ ma a eye kyɛn so a wode bedi w’ahiade nyinaa ho dwuma, sɛ́ ebia woyɛ obi a woafi ase anaasɛ woyɛ onimdefo no. 

### [.gitignore Fael a wɔrebɔ](creating-a-gitignore-file-twi.md)

Saa krataa yi kyerɛkyerɛ .gitignore fael atirimpɔw, nea enti a wode bedi dwuma, ne sɛnea wobɛbɔ bi.
Ɛkame ayɛ sɛ wɔde saa fael yi di dwuma wɔ Git nnwuma nyinaa mu.
