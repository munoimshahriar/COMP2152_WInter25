[![Houb el tatbi9ate el hourra](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)](https://github.com/ellerbrock/open-source-badges/)
[<img align="right" width="150" src="https://firstcontributions.github.io/assets/Readme/join-slack-team.png">](https://join.slack.com/t/firstcontributors/shared_invite/zt-1hg51qkgm-Xc7HxhsiPYNN3ofX2_I8FA)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Open Source Helpers](https://www.codetriage.com/roshanjossey/first-contributions/badges/users.svg)](https://www.codetriage.com/roshanjossey/first-contributions)


# Awel mouchraka 🇩🇿

Dayemen kayen mochkile ki nebdaw hadja men el bidaya. El khawof ta3 edire khatae daymen machi melih, khousousan ki techarek fi el code. Bessah 3alem el tatbi9ate el hourine mawodjoud bache etcharek wo tekhdem fi madjemou3a. Tani, Rana habine nebesstou el ta3lime ta3 el moucharraka el djadidda fel tatbi9ate el hourra bi ta3lime kifache techarek lil merra el oulla.

Te9rra ma9alate wa les tutos te9derre te3awonek, bessah wache howa afdel mine tehawolle tessiyi bela ma eddire akhtae ? Hadda el machrou3 medyoure bache yaa3ti nassaihe wo y ssahel tari9ate kifache li maya3rfouche bache eydirrou el moucharaka el oulla ta3houme. Etfekare : 9edma tekoune alaise, 9edma tet3alem bezaf. Wolla rak hab etcharek lel merra el oulla, teba3 el khtouwate el djaya. Wallah, rah tekoune moussaliya.

<img align="right" width="300" src="https://firstcontributions.github.io/assets/Readme/fork.png" alt="embrancher ce repertoire" />

Wolla ma3endekche git fel ordinateur ta3ek, [ tell3ou be rabet ]( https://help.github.com/articles/set-up-git/ ).

## Forker hadda el garage (ne3aytoulou tani Fork)

Forker el garage ki teklicker 3ala zire Fork el fow9e ta3 el safeha.
Hada rah yecrée nousskha tabe9 el assel ta3 el garage fi github ta3ek.

## Enssoukhe el garage 3andek fel PC

<img align="right" width="300" src="https://firstcontributions.github.io/assets/Readme/clone.png" alt="clonez ce répertoire" />

Dourka, enssoukhe hada el garage 3ala el PC diyalek. Clické 3ala el zire enssoukhe menba3ede eclicker 3ala l'icone *copié fi presse papier ta3ek*.

Eftah la console ta3 les commandes (ida rak fi windows) wola el terminale (ida rak fi MacOS ou Linux) menba3de cheghale lé commandes git el taliya :

```
git clone "l'url eli copietha dourk berk"
```
wine "l'url eli copietha dourk berk" (bela lé guillemets) hiya l'url ta3 el garage. chouf fi eli fate men 9abel bache tethassel 3ala l'url.

<img align="right" width="300" src="https://firstcontributions.github.io/assets/Readme/copy-to-clipboard.png" alt="copier l'URL dans le presse-papier" />

Mithale :
```
git clone https://github.com/issem-el-mousstakhdem-ta3ek/first-contributions.git
```

wine `issem-el-mousstakhdem-ta3ek` howa issem el mousstakhdem ta3 el compte ta3ek github, hena rak tecopier ga3 el mouhtawa ta3 el garage `first-contributions` mine Github lel PC diyalek.

## Ecréyé far3e

Rouhe lel garage ta3 el projet eli créyitou djedide mousstenssakhe (edha marakeche déja fih)

```
cd first-contributions
```

Dourka ecréyé far3e be la commande `git checkout` :

```
git checkout -b <add-essem-diyalek>
```

Mithale :
```
git checkout -b add-koffi-sani
```
(Esseme el far3e mayahtajeche yekoune fih kelmete *add*, mé hadja meliha loukane yekoune fih hadef lel fare3 wo tezide esseme diyalek lel lista.)

## Dire el taghyirate el mouhima é kemle fiha

Dourka, efteh el féchiyé `Contributors.md` fi un editeur de text, zid fih assmek, menba3de ahfedou, Idha fetehte le terminal ou derte la commande `git status`, rah etchouf beli kayen taghyérates. Zid hadouk al taghiyérates lel far3e eli créyeteho men 9bel be la commande `git add` :
```
git add Contributors.md
```

Dourka, kemel commité hadouk étaghyérates be la commande `git commit`:

```
git commit -m "Add <essem-diyalek> to Contributors list"
```
Ghéyere `<essem-diyalek>` bel assem diyalek.

## Eb3athe el tagheyérates fi github

Ebe3athes el taghyérates diyalek be la commande `git push` :
```
git push origin <add-essem-diyalek>
```
Bedel `<add-essem-diyalek>` be esseme el far3e eli créyeteho men 9abel.

## Présenté el taghyérates ta3ek lel fahsse

Idha rahet lel garage diyalek 3ala github, rah etchouffe beli kayen zire `Compare & pull request`, éclické 3ala el zire hadek.

<img style="float: right;" src="https://firstcontributions.github.io/assets/Readme/compare-and-pull.png" alt="create a pull request" />

Dourka présenter el talebe diyalek lel fahsse.

<img style="float: right;" src="https://firstcontributions.github.io/assets/Readme/submit-pull-request.png" alt="submit pull request" />

Fi zamen saghire rah ene fuzioné el taghyérates ta3ek me3a el fare3 main ta3 el projet hada, Yewosselek rissala ta3 el taghyérates ghire ki tendare la fusion kamel.

El far3e main ta3ek marahe yessralou hata taghyiére lel ane. Bache main ta3ek yekoune moutwafek me3a ta3i, lazem tabe3 hadou lé el khoutouwates :

## Khelli el main ta3ek synchronisé me3a hada el garage

 Bache tebda, rouhe lel fare3 main
 ```
 git checkout main
 ```

 Zide l'url ta3 el garage ta3ek ki `upstream remote url` :
```
git remote add upstream https://github.com/Roshanjossey/first-contributions
```

Hada rah tekoune tarika bache te9oule lel git beli kayen version wahdoukhera texister bi had el 3ounwane wo nettb9ou a3lihe `upstream`. Ghire el tagheyérates tet fuzionna, hawosse 3ala la version djedidda ta3 el garrage ta3i :
```
git fetch upstream
```

Henya rana nehawossou 3ala teghyérates fel main ta3i (upstream remote). Dourka, rahe tefusioner el taghyére el djadid ta3 el garage ta3i me3a el far3e ta3ek main :
```
git rebase upstream/main
```
Henya rahe neteb9ou ga3 el taghyérates eli rak tehawosse a 3lihoume fel far3e main. Idha be3ate el far3e main dourka, el main ta3ek rahe yekoune howa tani fih taghéyérates :
```
git push origin main
```
Tahedire: Hadi el khetra, rah tebe3aye el garage el be3ide eli assmou origin.

Fi hade el marhala rani fusionite el far3e `<add-essem-diyalek>` me3a el far3e main, wo enta fusionite el far3e main ta3i me3a el far3e main ta3ek. el far3e `<add-essem-diyalek>` maraheche nahtajouhe, edane te9dere tessuprimihe :

```
git branch -d <add-essem-diyalek>
```
wa aydan te9dere tenihi la version ta3ou fel far3e el be3ide tani :
```
git push origin --delete <add-essem-diyalek>
```
Wache cheft henaya machi darouri, bessah assem el far3e yewori beli el hadef rahe moukhassasse.

## Tuto besste3male adawates wahdoukhra


| <a href="../gui-tool-tutorials/github-desktop-tutorial.md"><img alt="GitHub Desktop" src="https://desktop.github.com/images/desktop-icon.svg" width="100"></a> | <a href="../gui-tool-tutorials/github-windows-vs2017-tutorial.md"><img alt="Visual Studio 2017" src="https://upload.wikimedia.org/wikipedia/commons/c/cd/Visual_Studio_2017_Logo.svg" width="100"></a> | <a href="../gui-tool-tutorials/gitkraken-tutorial.md"><img alt="GitKraken" src="https://firstcontributions.github.io/assets/gui-tool-tutorials/gitkraken-tutorial/gk-icon.png" width="100"></a> | <a href="../gui-tool-tutorials/github-windows-vs-code-tutorial.md"><img alt="VS Code" src="https://upload.wikimedia.org/wikipedia/commons/1/1c/Visual_Studio_Code_1.35_icon.png" width=100></a> | <a href="../gui-tool-tutorials/sourcetree-macos-tutorial.md"><img alt="Sourcetree App" src="https://wac-cdn.atlassian.com/dam/jcr:81b15cde-be2e-4f4a-8af7-9436f4a1b431/Sourcetree-icon-blue.svg" width=100></a> | <a href="../gui-tool-tutorials/github-windows-intellij-tutorial.md"><img alt="IntelliJ IDEA" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/IntelliJ_IDEA_Icon.svg/512px-IntelliJ_IDEA_Icon.svg.png" width=100></a> |
| --- | --- | --- | --- | --- | --- |
| [GitHub Desktop](../gui-tool-tutorials/github-desktop-tutorial.md) | [Visual Studio 2017](../gui-tool-tutorials/github-windows-vs2017-tutorial.md) | [GitKraken](../gui-tool-tutorials/gitkraken-tutorial.md) | [Visual Studio Code](../gui-tool-tutorials/github-windows-vs-code-tutorial.md) | [Atlassian Sourcetree](../gui-tool-tutorials/sourcetree-macos-tutorial.md) | [IntelliJ IDEA](../gui-tool-tutorials/github-windows-intellij-tutorial.md) |
