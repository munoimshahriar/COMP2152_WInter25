[![kɔmpiutaɖoɖo femaxee ƒe Lɔlɔ̃](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)](https://github.com/ellerbrock/open-source-badges/)
[<img align="right" width="150" src="https://firstcontributions.github.io/assets/Readme/join-slack-team.png">](https://join.slack.com/t/firstcontributors/shared_invite/zt-1hg51qkgm-Xc7HxhsiPYNN3ofX2_I8FA)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Open Source Helpers](https://www.codetriage.com/roshanjossey/first-contributions/badges/users.svg)](https://www.codetriage.com/roshanjossey/first-contributions)


# Kpekpeɖeŋu Gbãtɔ

Esesẽna ɣesiaɣi ne èwɔ nane zi gbãtɔ.Vɔvɔ̃ be yeawɔ vodadawo meɖea dzi ɖi kura o, vevietɔ ne èle nu wɔm aduadu.Gake kɔmpiutadziɖoɖo siwo wozãna faa ƒe xexeame ku ɖe nuwɔwɔ aduadu kple dɔwɔwɔ le ƒuƒoƒo me ŋu.Azɔ hã, míedi be míana wòanɔ bɔbɔe na kɔmpiutadziɖoɖo yeye siwo tsɔa nu faa femaxee la be woasrɔ̃ nu to alesi nàdzɔ nu zi gbãtɔ la fiafia wò me.

Nyatiwo kple nufiamewo xexlẽ ate ŋu akpe ɖe ŋuwò, gake nukae nyo wu be nàdze agbagba eye màte ŋu awɔ vodada o? Dɔ sia ƒe taɖodzinue nye be wòana mɔfiame eye wòana alesi dɔsrɔ̃viwo wɔa woƒe nudzɔdzɔ gbãtɔ nanɔ bɔbɔe.Ðo ŋku edzi be: zi alesi nèfa tu la, zi nenemae nèsrɔ̃a nu nyuie wu.Ne èdi vevie be yeadzɔ nu gbãtɔ la, ɖeko nàwɔ ɖe afɔɖeɖe siawo dzi.Medo ŋugbe be anye modzakaɖeɖe.

<img align="right" width="300" src="https://firstcontributions.github.io/assets/Readme/fork.png" alt="ŋe asi ɖe nu sia ŋu" />

Ne git mele wò kɔmpiuta dzi o, [ tsɔe de wò kɔmpiuta dzi ]( https://help.github.com/articles/set-up-git/ ).

## Miɖe asi le agbalẽdzraɖoƒe sia (si woyɔna hã be Fork) .

Ne èdi be yeaʋu agbalẽvi sia la, zi dzi le aɖaka si nye "Fork" si le axa la ƒe tame.
Esia ana be woaŋlɔ nyatakaka siwo le nyatakakadzraɖoƒea ɖe wò asitelefon dzi.

## Wɔ numekugbalẽvi sia ƒe kɔpi

<img align="right" width="300" src="https://firstcontributions.github.io/assets/Readme/clone.png" alt="Wɔ numekugbalẽvi sia ƒe kɔpi" />

Azɔ wɔ agbalẽdzraɖoƒe sia ƒe nɔnɔmetata ɖe wò kɔmpiuta dzi. Zi clone ƒe dzesi dzi emegbe nàzi dzesi la dzi</b> *kɔpi ɖe agbalẽƒomɔ̃ me*.

Ʋu kpovitɔ eye nàzã git se siwo gbɔna :

```
git clone "url si nèwɔ kɔpi na fifia"
```
afisi "url si nèwɔ kɔpi teti koe nye ema" (si me nyayɔyɔawo mele o) nye url si le agbalẽdzraɖoƒea. Kpɔ akpa si do ŋgɔ be nàxɔ url la.

<img align="right" width="300" src="https://firstcontributions.github.io/assets/Readme/copy-to-clipboard.png" alt="copier l'URL dans le presse-papier" />

Le kpɔɖeŋu me :
```
git clone https://github.com/wò-ŋkɔ-si-nèzãna/first-contributions.git
```
afisi `Wò ŋkɔ si nèzãna` nye wò GitHub zãla ƒe ŋkɔ. Afisiae nèle nusiwo le agbalẽdzraɖoƒea ƒe kɔpi wɔm le `first-contributions` tso GitHub dzi le wò kɔmpiuta dzi.

## Wɔ alɔdzedɔwɔƒe aɖe

Ʋu yi dɔwɔwɔ ƒe nɔnɔmetata yeye si wowɔ ƒe nɔnɔmetata me (ne mèle afima haɖe o):

```
cd first-contributions
```
Azɔ wɔ alɔdze aɖe kple sededea `git checkout` :
```
git checkout -b <wò-ŋkɔ>
```

Le kpɔɖeŋu me :
```
git checkout -b add-abdou-raouf-atarmla
```
(Mehiã be nya *add* nanɔ alɔdzedɔwɔƒea ƒe ŋkɔ me o, gake esɔ be nàde eme elabena taɖodzinu si le alɔdze sia ŋue nye be wòatsɔ wò ŋkɔ akpe ɖe xexlẽdzesi aɖe ŋu.)

## Wɔ tɔtrɔ siwo hiã eye nàtsɔ wo ana

Azɔ ʋu nuŋlɔɖia `Contributors.md` de wò ŋkɔ ɖe etame eye nàŋlɔe ɖi. Ne èʋu sedede ƒe nyatakakadzraɖoƒea eye nèwɔ sededea  `git status`, àkpɔe be tɔtrɔwo li. Tsɔ tɔtrɔ siawo kpe ɖe alɔdze si nèwɔ fifia kple sededea ŋu  `git add` :
```
git add Contributors.md
```

Azɔ wɔ tɔtrɔ siawo kple sededea `git commit`:
```
git commit -m "Tsɔ <wò-ŋkɔ> kpe ɖe Nudzɔlawo ƒe xexlẽdzesi ŋu"
```
tsɔ wò ŋkɔ ɖɔli `<wò-ŋkɔ>`.

## Tu tɔtrɔwo ɖe GitHub dzi

Tu wò tɔtrɔwo kple sededea `git push` :
```
git push origin <wò-ŋkɔ>
```
tsɔ alɔdze si wowɔ va yi ƒe ŋkɔ ɖɔli `<wò-ŋkɔ>`.

## Miɖo miaƒe tɔtrɔwo ɖa be woalé ŋku ɖe wo ŋu

Ne èyi wò nudzraɖoƒe le Github la, àkpɔ `Compare & pull request` ƒe dzesi. Zi dzesi sia dzi.

<img style="float: right;" src="https://firstcontributions.github.io/assets/Readme/compare-and-pull.png" alt="create a pull request" />

Azɔ tsɔ hehe ƒe biabiaa ɖo ɖa.

<img style="float: right;" src="https://firstcontributions.github.io/assets/Readme/submit-pull-request.png" alt="submit pull request" />

Eteƒe madidi o, maƒo miaƒe tɔtrɔwo katã nu ƒu ɖe dɔ sia ƒe alɔdze vevitɔ me. Àxɔ nyatakaka to e-mail dzi ne wonya wu ƒoƒo ɖekae nu ko.

Womatrɔ asi le miaƒe alɔdzedɔwɔƒea ƒe alɔdzedɔwɔƒe gãtɔ ŋu le ɣeyiɣi sia me o. Be wò spur nawɔ ɖeka kple tɔnye la, wɔ ɖe afɔɖeɖe siawo dzi.

## Na wò alɔdzedɔwɔƒea nawɔ ɖeka kple nyatakakadzraɖoƒe sia

 Gbã la, trɔ ɖe alɔdzedɔwɔƒe gã la ŋu (main)
 ```
 git checkout main
 ```

 Eye nàtsɔ nye nyatakakadzraɖoƒe ƒe ka akpee be  `upstream remote url` :
```
git remote add upstream https://github.com/Roshanjossey/first-contributions
```
Esia nye mɔ si dzi míetona gblɔna be nu bubu aɖe hã li si le míaƒe nyatakakadzraɖoƒea si míeyɔna be `upstream`. Ne tɔtrɔawo va wɔ ɖeka ko la, di nye numekuku ƒe akpa yeyea:
```
git fetch upstream
```

Afisiae míele tɔtrɔwo katã dim le nye alɔdzedɔwɔƒe (upstream remote) me. Fifia ele be nàƒo tɔtrɔ yeye si tso nye agbalẽdzraɖoƒea nu ƒu ɖe wò alɔdze gã la me:
```
git rebase upstream/main
```
Le afisia la, míewɔa tɔtrɔ siwo katã dim nènɔ la ŋudɔ le alɔdzedɔwɔƒe gã la me. Ne ètu alɔdze gã la fifia la, tɔtrɔ siawo hã anɔ wò fɔkpaa ŋu:
```
git push origin main
```
Nuxlɔ̃ame: Fifia ya èle tutum ayi adzɔge ʋĩ ƒe nyatakakadzraɖoƒe si woyɔna be origin.

Le afisia la, metsɔ wò `<wò-ŋkɔ>` alɔdzedɔwɔƒea ƒo ƒu kple nye alɔdze gãtɔ, eye nètsɔ nye alɔdze gã la ƒo ƒu kple wò alɔdze gãtɔ. Wò `<wò-ŋkɔ>` alɔdze megahiã o, eyata àteŋu atutue:
```
git branch -d <wò-ŋkɔ>
```
eye àte ŋu atutu eƒe tɔtrɔ le adzɔge ʋĩ ƒe nyatakakadzraɖoƒe hã:
```
git push origin --delete <wò-ŋkɔ>
```
Esia mehiã o, gake alɔdzedɔwɔƒea ƒe ŋkɔ ɖee fia be eƒe taɖodzinua nye nu si le vevie. Eƒe agbenɔɣi ate ŋu anɔ kpuie.

## Nufiame siwo zãa dɔwɔnu bubuwo


| <a href="../gui-tool-tutorials/github-desktop-tutorial.md"><img alt="GitHub Desktop" src="https://desktop.github.com/images/desktop-icon.svg" width="100"></a> | <a href="../gui-tool-tutorials/github-windows-vs2017-tutorial.md"><img alt="Visual Studio 2017" src="https://upload.wikimedia.org/wikipedia/commons/c/cd/Visual_Studio_2017_Logo.svg" width="100"></a> | <a href="../gui-tool-tutorials/gitkraken-tutorial.md"><img alt="GitKraken" src="https://firstcontributions.github.io/assets/gui-tool-tutorials/gitkraken-tutorial/gk-icon.png" width="100"></a> | <a href="../gui-tool-tutorials/github-windows-vs-code-tutorial.md"><img alt="VS Code" src="https://upload.wikimedia.org/wikipedia/commons/1/1c/Visual_Studio_Code_1.35_icon.png" width=100></a> | <a href="../gui-tool-tutorials/sourcetree-macos-tutorial.md"><img alt="Sourcetree App" src="https://wac-cdn.atlassian.com/dam/jcr:81b15cde-be2e-4f4a-8af7-9436f4a1b431/Sourcetree-icon-blue.svg" width=100></a> | <a href="../gui-tool-tutorials/github-windows-intellij-tutorial.md"><img alt="IntelliJ IDEA" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/IntelliJ_IDEA_Icon.svg/512px-IntelliJ_IDEA_Icon.svg.png" width=100></a> |
| --- | --- | --- | --- | --- | --- |
| [GitHub Desktop](../gui-tool-tutorials/github-desktop-tutorial.md) | [Visual Studio 2017](../gui-tool-tutorials/github-windows-vs2017-tutorial.md) | [GitKraken](../gui-tool-tutorials/gitkraken-tutorial.md) | [Visual Studio Code](../gui-tool-tutorials/github-windows-vs-code-tutorial.md) | [Atlassian Sourcetree](../gui-tool-tutorials/sourcetree-macos-tutorial.md) | [IntelliJ IDEA](../gui-tool-tutorials/github-windows-intellij-tutorial.md) |

## Afikae míayi emegbe?

Àte ŋu awɔ ɖeka kple míaƒe ƒuƒoƒoa hã le Slack nenye be èhiã kpekpeɖeŋu alo nyabiase aɖewo le asiwò.  [Wɔ ɖeka kple ƒuƒoƒoa le Slack dzi](https://join.slack.com/t/firstcontributors/shared_invite/zt-1hg51qkgm-Xc7HxhsiPYNN3ofX2_I8FA)
