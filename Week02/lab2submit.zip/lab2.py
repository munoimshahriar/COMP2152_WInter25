import random

# Define the weapons array
weapons = ["Fist", "Knife", "Club", "Gun", "Bomb", "Nuclear bomb"]

try:
    # Roll the dice (1-6)
    weaponRoll = random.randint(1, 6)
    print(f"You rolled: {weaponRoll}")

    # Add weaponRoll to hero's combat strength
    hero_combat_strength = 10  # Example combat strength
    hero_combat_strength += weaponRoll
    print(f"Hero's combat strength: {hero_combat_strength}")

    # Use weaponRoll as an index into the weapons array
    weapon = weapons[weaponRoll - 1]
    print(f"Hero's weapon: {weapon}")

    # Conditions based on weaponRoll
    if weaponRoll <= 2:
        print("You rolled a weak weapon, friend.")
    elif weaponRoll <= 4:
        print("Your weapon is meh.")
    else:
        print("Nice weapon, friend!")

    # Check if the weapon is not a Fist
    if weapon != "Fist":
        print("Thank goodness you didn't roll the Fist...")

except Exception as e:
    print(f"An error occurred: {e}")
